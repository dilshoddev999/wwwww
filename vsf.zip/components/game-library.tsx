"use client"

import { motion } from "framer-motion"
import { Play, Download, Cog } from "lucide-react"

const games = [
  {
    id: 1,
    title: "Vanilla Minecraft",
    version: "v1.20.4",
    image: "/minecraft-vanilla-game.jpg",
    status: "installed",
    playtime: "2,450 soat",
  },
  {
    id: 2,
    title: "Forge Modded",
    version: "v1.20.1",
    image: "/minecraft-forge-mods.jpg",
    status: "installed",
    playtime: "1,200 soat",
  },
  {
    id: 3,
    title: "Fabric Server",
    version: "v1.20.4",
    image: "/minecraft-fabric-server.jpg",
    status: "downloading",
    playtime: "450 soat",
  },
  {
    id: 4,
    title: "Creative Mode",
    version: "v1.20.4",
    image: "/minecraft-creative.jpg",
    status: "available",
    playtime: "0 soat",
  },
]

export function GameLibrary() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Oʻyinlar Kutubxonasi</h2>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {games.map((game) => (
          <motion.div
            key={game.id}
            variants={itemVariants}
            whileHover={{ y: -8, transition: { duration: 0.2 } }}
            className="group cursor-pointer"
          >
            <div className="relative bg-secondary rounded-lg overflow-hidden border border-border hover:border-accent transition-all">
              <div className="relative h-40 overflow-hidden">
                <img
                  src={game.image || "/placeholder.svg"}
                  alt={game.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors"></div>
              </div>

              <div className="p-3 space-y-2">
                <h3 className="font-semibold text-foreground text-sm">{game.title}</h3>
                <p className="text-xs text-muted-foreground">{game.version}</p>
                <p className="text-xs text-accent">Oʻyin vaqti: {game.playtime}</p>

                <div className="flex gap-2 pt-2">
                  {game.status === "installed" && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex-1 bg-accent text-accent-foreground py-2 rounded text-xs font-semibold flex items-center justify-center gap-1 hover:bg-accent/90 transition-colors"
                    >
                      <Play className="w-3 h-3" /> Oʻyna
                    </motion.button>
                  )}
                  {game.status === "available" && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex-1 bg-accent text-accent-foreground py-2 rounded text-xs font-semibold flex items-center justify-center gap-1 hover:bg-accent/90 transition-colors"
                    >
                      <Download className="w-3 h-3" /> Yukla
                    </motion.button>
                  )}
                  {game.status === "downloading" && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex-1 bg-muted text-muted-foreground py-2 rounded text-xs font-semibold flex items-center justify-center gap-1 cursor-not-allowed"
                    >
                      Yuklash...
                    </motion.button>
                  )}

                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-2 py-2 rounded border border-border hover:border-accent transition-colors"
                  >
                    <Cog className="w-3 h-3 text-foreground" />
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  )
}
